#!/bin/bash

# Accept the InSpec license
export INSPEC_LICENSE="accept"

# Detect the OS and run corresponding profiles
PROFILE_DIR="/app/src"
REPORT_DIR="/app/reports"

# Validate environment variables
if [ ! -d "$PROFILE_DIR" ]; then
  echo "PROFILE_DIR does not exist. Creating directory: $PROFILE_DIR"
  mkdir -p "$PROFILE_DIR"
fi

if [ ! -d "$REPORT_DIR" ]; then
  echo "REPORT_DIR does not exist. Creating directory: $REPORT_DIR"
  mkdir -p "$REPORT_DIR"
fi

# Define the log file location
LOG_FILE="$REPORT_DIR/execution.log"

# Initialize the log file
echo "Execution log initialized on $(date)" > "$LOG_FILE"

# Add error handling for inspec commands
run_inspec() {
  local profile=$1
  local report=$2
  if ! inspec exec "$profile" --reporter html:"$report"; then
    echo "Error: Failed to execute profile $profile" >> "$LOG_FILE"
  else
    echo "Success: Profile $profile executed successfully" >> "$LOG_FILE"
  fi
}

# Detect web server configuration files and run corresponding control scripts
WEB_SERVERS=("apache" "nginx" "iis" "jboss" "tomcat7" "tomcat8" "tomcat9" "ibm-httpd" "ibm-websphere" "tomcat-windows")
CONFIG_DIR="/app/test"

DETECTED=false

for SERVER in "${WEB_SERVERS[@]}"; do
  CONFIG_FILES="$CONFIG_DIR/$SERVER"
  if [ -d "$CONFIG_FILES" ]; then
    DETECTED=true
    CONFIG_NAME=$(basename "$CONFIG_FILES")
    echo "Detected configuration files for web server: $CONFIG_NAME" >> "$LOG_FILE"

    # Perform checks on configuration files
    for FILE in $(find "$CONFIG_FILES" -type f); do
      echo "Checking file: $FILE" >> "$LOG_FILE"
      if [ -r "$FILE" ]; then
        echo "File $FILE is readable and valid." >> "$LOG_FILE"
      else
        echo "File $FILE is not readable or valid." >> "$LOG_FILE"
      fi
    done

    # Run the corresponding control script
    run_inspec "src/$SERVER" "$REPORT_DIR/$SERVER.html"
  fi
done

if [ "$DETECTED" = false ]; then
  echo "No specific web server configuration detected. Running all profiles as fallback." >> "$LOG_FILE"
  for SERVER in "${WEB_SERVERS[@]}"; do
    run_inspec "src/$SERVER" "$REPORT_DIR/$SERVER.html"
  done
fi