#!/bin/bash

# Accept the InSpec license
export INSPEC_LICENSE="accept"

# Detect the OS and run corresponding profiles
PROFILE_DIR="/app/src"
REPORT_DIR="/app/reports"

# Validate environment variables
if [ ! -d "$PROFILE_DIR" ]; then
  echo "PROFILE_DIR does not exist. Creating directory: $PROFILE_DIR"
  mkdir -p "$PROFILE_DIR"
fi

if [ ! -d "$REPORT_DIR" ]; then
  echo "REPORT_DIR does not exist. Creating directory: $REPORT_DIR"
  mkdir -p "$REPORT_DIR"
fi

# Define the log file location
LOG_FILE="$REPORT_DIR/execution.log"

# Initialize the log file
echo "Execution log initialized on $(date)" > "$LOG_FILE"

# Add error handling for inspec commands
run_inspec() {
  local profile=$1
  local report=$2
  if ! inspec exec "$profile" --reporter json:"$report"; then
    echo "Error: Failed to execute profile $profile" >> "$LOG_FILE"
  else
    echo "Success: Profile $profile executed successfully" >> "$LOG_FILE"
  fi
}

# Detect OS configuration and run corresponding control scripts
if [ -f "/etc/redhat-release" ]; then
  echo "Detected RHEL-based Linux"
  run_inspec "$PROFILE_DIR/RHEL_7/rhel7_controls.rb" "$REPORT_DIR/rhel7_report.json"
  run_inspec "$PROFILE_DIR/RHEL_8/rhel8_controls.rb" "$REPORT_DIR/rhel8_report.json"
elif [ -f "/etc/lsb-release" ]; then
  echo "Detected Ubuntu-based Linux"
  run_inspec "$PROFILE_DIR/ubuntu_linux/ubuntu_controls.rb" "$REPORT_DIR/ubuntu_report.json"
elif [[ "$(uname -s)" =~ CYGWIN*|MINGW32*|MSYS*|MINGW* ]]; then
  echo "Detected Windows"
  run_inspec "$PROFILE_DIR/windows_server_2016/win2016_controls.rb" "$REPORT_DIR/win2016_report.json"
  run_inspec "$PROFILE_DIR/windows_server_2019/win2019_controls.rb" "$REPORT_DIR/win2019_report.json"
  run_inspec "$PROFILE_DIR/windows_server_2022/win2022_controls.rb" "$REPORT_DIR/win2022_report.json"
else
  echo "Unsupported or unknown OS"
  echo "Running all profiles as fallback"
  run_inspec "$PROFILE_DIR/RHEL_7/rhel7_controls.rb" "$REPORT_DIR/rhel7_report.json"
  run_inspec "$PROFILE_DIR/RHEL_8/rhel8_controls.rb" "$REPORT_DIR/rhel8_report.json"
  run_inspec "$PROFILE_DIR/ubuntu_linux/ubuntu_controls.rb" "$REPORT_DIR/ubuntu_report.json"
  run_inspec "$PROFILE_DIR/windows_server_2016/win2016_controls.rb" "$REPORT_DIR/win2016_report.json"
  run_inspec "$PROFILE_DIR/windows_server_2019/win2019_controls.rb" "$REPORT_DIR/win2019_report.json"
  run_inspec "$PROFILE_DIR/windows_server_2022/win2022_controls.rb" "$REPORT_DIR/win2022_report.json"
fi
