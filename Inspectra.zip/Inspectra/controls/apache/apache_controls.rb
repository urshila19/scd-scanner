title 'Apache Server Config'

#Check Apache config file owner, group and permissions.
apache_conf_path = File.expand_path('../config/httpd.conf', __dir__)     
apache_conf_dir  = File.expand_path('../config', __dir__)

# # 1. Ensure Apache Is Installed From the Appropriate Binaries
# control 'apache-installed-binary' do
#   impact 1.0
#   title 'Ensure Apache Is Installed From the Appropriate Binaries'
#   desc 'Apache should be installed from official package manager binaries.'
#   describe command('httpd -v || apache2 -v') do
#     its('stdout') { should match(/Server version: Apache\//) }
#   end
# end

# 2. Enable Only Necessary Authentication and Authorization Module
control 'apache-auth-modules' do
  impact 1.0
  title 'Enable Only Necessary Authentication and Authorization Module'
  desc 'Only required auth modules should be enabled.'
  describe file(apache_conf_path) do
    its('content') { should match(/^\s*LoadModule\s+authz_core_module\b/) }
  end
end

# 3. Enable the Log Config Module
control 'apache-log-config-module' do
  impact 1.0
  title 'Enable the Log Config Module'
  desc 'The log_config module should be enabled.'
  describe file(apache_conf_path) do
    its('content') { should match(/^\s*LoadModule\s+log_config_module\b/) }
  end
end

# 4. Disable WebDAV Modules
control 'apache-disable-webdav' do
  impact 1.0
  title 'Disable WebDAV Modules'
  desc 'WebDAV modules should not be enabled.'
  describe file(apache_conf_path) do
    its('content') { should_not match(/^\s*LoadModule\s+dav_module\b/) }
    its('content') { should_not match(/^\s*LoadModule\s+dav_fs_module\b/) }
    its('content') { should_not match(/^\s*LoadModule\s+dav_lock_module\b/) }
  end
end

# 5. Disable Status Module
control 'apache-disable-status' do
  impact 1.0
  title 'Disable Status Module'
  desc 'The status module should not be enabled.'
  describe file(apache_conf_path) do
    its('content') { should_not match(/^\s*LoadModule\s+status_module\b/) }
  end
end

# 6. Disable Autoindex Module
control 'apache-disable-autoindex' do
  impact 1.0
  title 'Disable Autoindex Module'
  desc 'The autoindex module should not be enabled.'
  describe file(apache_conf_path) do
    its('content') { should_not match(/^\s*LoadModule\s+autoindex_module\b/) }
  end
end

# 7. Disable Proxy Modules
control 'apache-disable-proxy' do
  impact 1.0
  title 'Disable Proxy Modules'
  desc 'Proxy modules should not be enabled.'
  describe file(apache_conf_path) do
    its('content') { should_not match(/^\s*LoadModule\s+proxy_module\b/) }
    its('content') { should_not match(/^\s*LoadModule\s+proxy_http_module\b/) }
    its('content') { should_not match(/^\s*LoadModule\s+proxy_ftp_module\b/) }
    its('content') { should_not match(/^\s*LoadModule\s+proxy_connect_module\b/) }
  end
end

# 8. Disable User Directories Modules
control 'apache-disable-userdir' do
  impact 1.0
  title 'Disable User Directories Modules'
  desc 'Userdir module should not be enabled.'
  describe file(apache_conf_path) do
    its('content') { should_not match(/^\s*LoadModule\s+userdir_module\b/) }
  end
end

# 9. Disable Info Module
control 'apache-disable-info' do
  impact 1.0
  title 'Disable Info Module'
  desc 'The info module should not be enabled.'
  describe file(apache_conf_path) do
    its('content') { should_not match(/^\s*LoadModule\s+info_module\b/) }
  end
end

# 10. Lock the Apache User Account
control 'apache-lock-user' do
  impact 1.0
  title 'Lock the Apache User Account'
  desc 'The Apache user account should be locked.'
  # Config-only check: look for a comment or marker in the config directory
  describe file(File.join(apache_conf_dir, 'apache-user-locked.txt')) do
    it { should exist }
    its('content') { should match(/locked|disabled|account is locked/i) }
  end
end

# 11. Set Ownership on Apache Directories and Files
control 'apache-ownership' do
  impact 1.0
  title 'Set Ownership on Apache Directories and Files'
  desc 'All Apache directories and files should be owned by root.'
  describe file(apache_conf_dir) do
    it { should be_owned_by 'root' }
    it { should be_grouped_into 'root' }
  end
  command("find #{apache_conf_dir} -type f").stdout.split.each do |f|
    describe file(f) do
      it { should be_owned_by 'root' }
      it { should be_grouped_into 'root' }
    end
  end
end

# 12. Set Group Id on Apache Directories and Files
control 'apache-setgid' do
  impact 1.0
  title 'Set Group Id on Apache Directories and Files'
  desc 'Set the setgid bit on Apache directories.'
  command("find #{apache_conf_dir} -type d").stdout.split.each do |d|
    describe file(d) do
      its('mode') { should cmp '02750' }
    end
  end
end

# 13. Restrict Other Write Access on Apache Directories and Files
control 'apache-no-other-write' do
  impact 1.0
  title 'Restrict Other Write Access on Apache Directories and Files'
  desc 'No Apache files or directories should be writable by others.'
  command("find #{apache_conf_dir} -perm -o+w").stdout.split.each do |f|
    describe file(f) do
      it { should_not be_writable.by('others') }
    end
  end
end

# 14. Secure Core Dump Directory
control 'apache-core-dump-dir' do
  impact 1.0
  title 'Secure Core Dump Directory'
  desc 'The core dump directory should be owned by root and not writable by others.'
  describe file('/var/log/apache2') do
    it { should be_owned_by 'root' }
    it { should_not be_writable.by('others') }
  end
end

# 15. Secure the Lock File
control 'apache-lock-file' do
  impact 1.0
  title 'Secure the Lock File'
  desc 'The Apache lock file should be owned by root and have permissions 0640.'
  describe file('/var/lock/apache2/accept.lock') do
    it { should be_owned_by 'root' }
    its('mode') { should cmp '0640' }
  end
end

# 16. Secure the Pid File
control 'apache-pid-file' do
  impact 1.0
  title 'Secure the Pid File'
  desc 'The Apache PID file should be owned by root and have permissions 0644.'
  describe file('/var/run/apache2/apache2.pid') do
    it { should be_owned_by 'root' }
    its('mode') { should cmp '0644' }
  end
end

# 17. Secure the ScoreBoard File
control 'apache-scoreboard-file' do
  impact 1.0
  title 'Secure the ScoreBoard File'
  desc 'The Apache scoreboard file should be owned by root and have permissions 0640.'
  describe file('/var/run/apache2/scoreboard') do
    it { should be_owned_by 'root' }
    its('mode') { should cmp '0640' }
  end
end

# 18. Restrict Group Write Access for the Apache Directories and Files
control 'apache-no-group-write' do
  impact 1.0
  title 'Restrict Group Write Access for the Apache Directories and Files'
  desc 'No Apache files or directories should be group writable.'
  command("find #{apache_conf_dir} -perm -g+w").stdout.split.each do |f|
    describe file(f) do
      it { should_not be_writable.by('group') }
    end
  end
end

# 19. Restrict Group Write Access for the Document Root Directories and Files
control 'apache-no-group-write-docroot' do
  impact 1.0
  title 'Restrict Group Write Access for the Document Root Directories and Files'
  desc 'No files or directories in the document root should be group writable.'
  docroot = '/var/www/html'
  command("find #{docroot} -perm -g+w").stdout.split.each do |f|
    describe file(f) do
      it { should_not be_writable.by('group') }
    end
  end
end

# 20. Ensure Access to Special Purpose Application Writable Directories is Properly Restricted
control 'apache-app-writable-dirs' do
  impact 1.0
  title 'Ensure Access to Special Purpose Application Writable Directories is Properly Restricted'
  desc 'Application-writable directories should not be world-writable.'
  app_dirs = ['/var/www/app/uploads', '/var/www/app/tmp']
  app_dirs.each do |dir|
    describe file(dir) do
      it { should_not be_writable.by('others') }
    end
  end
end

# 21. Deny Access to OS Root Directory
control 'apache-deny-root-dir' do
  impact 1.0
  title 'Deny Access to OS Root Directory'
  desc 'Access to the OS root directory should be denied.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(%r{<Directory />.*?Deny from all.*?</Directory>}m) }
  end
end



#Set the apache server token
control 'apache-04' do
  impact 1.0
  title 'Set the apache server token'
  desc '\'ServerTokens Prod\' tells Apache to return only Apache as product in the server response header on the every page request'

  describe file(File.join(apache_conf_dir, '/conf-enabled/security.conf')) do
    its('content') { should match(/^ServerTokens Prod/) }
  end
end



#Should not load certain legacy modules
control 'apache-05' do
  impact 1.0
  title 'Should not load certain modules'
  desc 'Apache HTTP should not load legacy modules'

  module_path = File.join(apache_conf_dir, '/mods-enabled/')
  loaded_modules = command('ls ' << module_path).stdout.split.keep_if { |file_name| /.load/.match(file_name) }

  loaded_modules.each do |id|
    describe file(File.join(module_path, id)) do
      its('content') { should_not match(/^\s*?LoadModule\s+?dav_module/) }
      its('content') { should_not match(/^\s*?LoadModule\s+?cgid_module/) }
      its('content') { should_not match(/^\s*?LoadModule\s+?cgi_module/) }
      its('content') { should_not match(/^\s*?LoadModule\s+?include_module/) }
    end
  end
end



#Disable TRACE-methods
control 'apache-06' do
  impact 1.0
  title 'Disable TRACE-methods'
  desc 'The web server doesn\'t allow TRACE request and help in blocking Cross Site Tracing attack.'

  describe file(File.join(apache_conf_dir, '/conf-enabled/security.conf')) do
    its('content') { should match(/^\s*?TraceEnable\s+?Off/) }
  end
end



#Disable insecure HTTP-methods
control 'apache-07' do
  impact 1.0
  title 'Disable insecure HTTP-methods'
  desc 'Disable insecure HTTP-methods and allow only necessary methods.'

  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^\s*?<LimitExcept\s+?GET\s+?POST>/) }
  end
end



#Enable Apache Logging
control 'apache-08' do
  impact 1.0
  title 'Enable Apache Logging'
  desc 'Apache allows you to logging independently of your OS logging. It is wise to enable Apache logging, because it provides more information, such as the commands entered by users that have interacted with your Web server.'

  sites_enabled_path = File.join(apache_conf_dir, '/sites-enabled/')
  loaded_sites = command('ls ' << sites_enabled_path).stdout.split.keep_if { |file_name| /.conf/.match(file_name) }

  loaded_sites.each do |id|
    describe file(File.join(sites_enabled_path, id)).content.gsub(/#.*$/, '').scan(%r{<virtualhost(.*?)<\/virtualhost>}im).flatten do
      it { should include(/CustomLog.*$/i) }
    end
  end
end

# 22. Allow Appropriate Access to Web Content
control 'apache-allow-web-content-access' do
  impact 1.0
  title 'Allow Appropriate Access to Web Content'
  desc 'Ensure only appropriate access is allowed to web content.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/<Directory \/var\/www\/html>/) }
    its('content') { should match(/Require all granted/) }
  end
end

# 23. Restrict Override for the OS Root Directory
control 'apache-restrict-override-os-root' do
  impact 1.0
  title 'Restrict Override for the OS Root Directory'
  desc 'Override should be None for the OS root directory.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/<Directory \/>/) }
    its('content') { should match(/AllowOverride None/) }
  end
end

# 24. Restrict Override for All Directories
control 'apache-restrict-override-all' do
  impact 1.0
  title 'Restrict Override for All Directories'
  desc 'AllowOverride should be None for all directories.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/AllowOverride None/) }
  end
end

# 25. Restrict Options for the OS Root Directory
control 'apache-restrict-options-os-root' do
  impact 1.0
  title 'Restrict Options for the OS Root Directory'
  desc 'Options should be None for the OS root directory.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/<Directory \/>/) }
    its('content') { should match(/Options None/) }
  end
end

# 26. Restrict Options for the Web Root Directory
control 'apache-restrict-options-web-root' do
  impact 1.0
  title 'Restrict Options for the Web Root Directory'
  desc 'Options should be limited for the web root directory.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/<Directory \/var\/www\/html>/) }
    its('content') { should match(/Options -Indexes -Includes -ExecCGI -FollowSymLinks/) }
  end
end

# 27. Minimize Options for Other Directories
control 'apache-minimize-options-other-dirs' do
  impact 1.0
  title 'Minimize Options for Other Directories'
  desc 'Options should be minimized for other directories.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/Options None/) }
  end
end

# 28. Remove Default HTML Content
control 'apache-remove-default-html' do
  impact 1.0
  title 'Remove Default HTML Content'
  desc 'Default HTML content should be removed.'
  describe file('/var/www/html/index.html') do
    it { should_not exist }
  end
end

# 29. Remove Default CGI Content printenv
control 'apache-remove-default-cgi-printenv' do
  impact 1.0
  title 'Remove Default CGI Content printenv'
  desc 'Default CGI printenv should be removed.'
  describe file('/usr/lib/cgi-bin/printenv') do
    it { should_not exist }
  end
end

# 30. Remove Default CGI Content test-cgi
control 'apache-remove-default-cgi-testcgi' do
  impact 1.0
  title 'Remove Default CGI Content test-cgi'
  desc 'Default CGI test-cgi should be removed.'
  describe file('/usr/lib/cgi-bin/test-cgi') do
    it { should_not exist }
  end
end

# 31. Limit HTTP Request Methods
control 'apache-limit-http-methods' do
  impact 1.0
  title 'Limit HTTP Request Methods'
  desc 'Only necessary HTTP methods should be allowed.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/<LimitExcept GET POST>/) }
    its('content') { should match(/Require all denied/) }
  end
end

# 32. Disable HTTP TRACE Method
control 'apache-disable-trace' do
  impact 1.0
  title 'Disable HTTP TRACE Method'
  desc 'TRACE method should be disabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/security.conf')) do
    its('content') { should match(/^TraceEnable Off/) }
  end
end

# 33. Restrict HTTP Protocol Versions
control 'apache-restrict-http-protocol' do
  impact 1.0
  title 'Restrict HTTP Protocol Versions'
  desc 'Restrict HTTP protocol versions.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/Protocols h2 http\/1.1/) }
  end
end

# 34. Restrict Access to .ht* files
control 'apache-restrict-ht-files' do
  impact 1.0
  title 'Restrict Access to .ht* files'
  desc 'Access to .ht* files should be restricted.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    it { should exist }
    its('content') { should_not be_empty }
    # Ensure .git block contains the deny directive
    its('content') { should match(/<FilesMatch\s+"\\?\.git"\s*>\s*\n\s*(Require all denied|Deny from all)\s*\n\s*<\/FilesMatch>/im) }
    # Ensure .svn block contains the deny directive
    its('content') { should match(/<FilesMatch\s+"\\?\.svn"\s*>\s*\n\s*(Require all denied|Deny from all)\s*\n\s*<\/FilesMatch>/im) }
  end
end

# 35. Restrict File Extensions
control 'apache-restrict-file-extensions' do
  impact 1.0
  title 'Restrict File Extensions'
  desc 'Restrict access to certain file extensions.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    # Match the <FilesMatch> block for file extensions with Require all denied inside, using four backslashes in the regex string to match two in the config
    its('content') { should match(/<FilesMatch\s+"\\\\.\(bak\|config\|sql\|fla\|psd\|ini\|log\|sh\|inc\|swp\|dist\|htaccess\|htpasswd\)\$">\s*Require all denied\s*<\/FilesMatch>/m) }
  end
end

# 36. Deny IP Address Based Requests
control 'apache-deny-ip-requests' do
  impact 1.0
  title 'Deny IP Address Based Requests'
  desc 'Deny requests made directly to the server IP.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/RewriteEngine On/) }
    its('content') { should match(/^\s*RewriteCond\s+%\{HTTP_HOST\}\s+\^\\d\+\\.\\d\+\\.\\d\+\\.\\d\+\$/) }
    its('content') { should match(/^\s*RewriteRule\s+\^\s*-\s*\[F\]/) }
  end
end

# 37. Restrict Listen Directive
control 'apache-restrict-listen' do
  impact 1.0
  title 'Restrict Listen Directive'
  desc 'Restrict Listen directive to specific IPs and ports.'
  describe file(apache_conf_path) do
    its('content') { should match(/^Listen 80/) }
  end
end

# 38. Restrict Browser Frame Options
control 'apache-restrict-frame-options' do
  impact 1.0
  title 'Restrict Browser Frame Options'
  desc 'Set X-Frame-Options header.'
  describe file(File.join(apache_conf_dir, '../config/security.conf')) do
    its('content') { should match(/Header always set X-Frame-Options\s+"SAMEORIGIN"/) }
  end
end

# 39. Configure the Error Log
control 'apache-error-log' do
  impact 1.0
  title 'Configure the Error Log'
  desc 'Error log should be configured.'
  describe file(apache_conf_path) do
    its('content') { should match(/^ErrorLog \/var\/log\/apache2\/error.log/) }
  end
end

# 40. Configure a Syslog Facility for Error Logging
control 'apache-syslog-error-log' do
  impact 1.0
  title 'Configure a Syslog Facility for Error Logging'
  desc 'Syslog facility should be configured for error logging.'
  describe file(apache_conf_path) do
    its('content') { should match(/^ErrorLog syslog:local1/) }
  end
end

# 41. Configure the Access Log
control 'apache-access-log' do
  impact 1.0
  title 'Configure the Access Log'
  desc 'Access log should be configured.'
  describe file(apache_conf_path) do
    its('content') { should match(/^CustomLog \/var\/log\/apache2\/access.log combined/) }
  end
end

# 42. Log Storage and Rotation
control 'apache-log-rotation' do
  impact 1.0
  title 'Log Storage and Rotation'
  desc 'Log storage and rotation should be configured.'
  describe file('/Users/KMBL400649/Documents/Config_Check_Project/apache-profile/config/etc/logrotate.d/apache2') do
    it { should exist }
    its('content') { should match(/rotate \d+/) }
    its('content') { should match(/weekly|daily|monthly/) }
  end
end

# 43. Install mod_ssl and/or mod_nss
control 'apache-mod-ssl' do
  impact 1.0
  title 'Install mod_ssl and/or mod_nss'
  desc 'mod_ssl or mod_nss should be installed.'
  describe file(apache_conf_path) do
    its('content') { should match(/^\s*LoadModule\s+(ssl_module|nss_module)\b/) }
  end
end

# 44. Install a Valid Trusted Certificate
control 'apache-valid-cert' do
  impact 1.0
  title 'Install a Valid Trusted Certificate'
  desc 'A valid trusted certificate should be installed.'
  describe file(File.join(apache_conf_dir, 'ssl/apache.crt')) do
    it { should exist }
    its('content') { should match(/BEGIN CERTIFICATE/) }
  end
end

# 45. Protect the Server's Private Key
control 'apache-protect-key' do
  impact 1.0
  title 'Protect the Server\'s Private Key'
  desc 'The private key should have permissions 400.'
  describe file(File.join(apache_conf_dir, 'ssl/apache.key')) do
    it { should exist }
    its('mode') { should cmp '0400' }
  end
end

# 46. Disable the SSL v3.0 Protocol
control 'apache-disable-ssl3' do
  impact 1.0
  title 'Disable the SSL v3.0 Protocol'
  desc 'SSL v3.0 should be disabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should_not match(/SSLProtocol.*SSLv3/) }
  end
end

# 47. Restrict Weak SSL/TLS Ciphers
control 'apache-restrict-weak-ciphers' do
  impact 1.0
  title 'Restrict Weak SSL/TLS Ciphers'
  desc 'Weak SSL/TLS ciphers should be disabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should_not match(/SSLHonorCipherOrder Off/) }
    its('content') { should_not match(/SSLProtocol.*(SSLv2|SSLv3)/) }
    its('content') { should_not match(/SSLCipherSuite.*(NULL|EXP|LOW|MD5|RC4)/) }
  end
end

# 48. Disable SSL Insecure Renegotiation
control 'apache-disable-insecure-reneg' do
  impact 1.0
  title 'Disable SSL Insecure Renegotiation'
  desc 'SSL insecure renegotiation should be disabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should_not match(/SSLInsecureRenegotiation on/) }
  end
end

# 49. Ensure SSL Compression is not Enabled
control 'apache-no-ssl-compression' do
  impact 1.0
  title 'Ensure SSL Compression is not Enabled'
  desc 'SSL compression should not be enabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should_not match(/SSLCompression on/) }
  end
end

# 50. Restrict Medium Strength SSL/TLS Ciphers
control 'apache-restrict-medium-ciphers' do
  impact 1.0
  title 'Restrict Medium Strength SSL/TLS Ciphers'
  desc 'Medium strength SSL/TLS ciphers should be restricted.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should_not match(/SSLCipherSuite.*MEDIUM/) }
  end
end

# 51. Disable the TLS v1.0 Protocol
control 'apache-disable-tls10' do
  impact 1.0
  title 'Disable the TLS v1.0 Protocol'
  desc 'TLS v1.0 should be disabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should_not match(/SSLProtocol.*TLSv1( |$)/) }
  end
end

# 52. Disable the TLS v1.1 Protocol
control 'apache-disable-tls11' do
  impact 1.0
  title 'Disable the TLS v1.1 Protocol'
  desc 'TLS v1.1 should be disabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should_not match(/SSLProtocol.*TLSv1\.1/) }
  end
end

# 53. Enable TLS v1.2 and above
control 'apache-enable-tls12' do
  impact 1.0
  title 'Enable TLS v1.2 and above'
  desc 'TLS v1.2 and above should be enabled.'
  describe file(File.join(apache_conf_dir, '../config/ssl.conf')) do
    its('content') { should match(/SSLProtocol\s+TLSv1.2/) }
  end
end

# 54. Enable OCSP Stapling
control 'apache-ocsp-stapling' do
  impact 1.0
  title 'Enable OCSP Stapling'
  desc 'OCSP stapling should be enabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should match(/SSLUseStapling on/) }
  end
end

# 55. Enable HTTP Strict Transport Security
control 'apache-hsts' do
  impact 1.0
  title 'Enable HTTP Strict Transport Security'
  desc 'HSTS header should be set.'
  describe file(File.join(apache_conf_dir, '../config/security.conf')) do
    its('content') { should match(/Header always set Strict-Transport-Security/) }
  end
end

# 56. Ensure Only Cipher Suites That Provide Forward Secrecy Are Enabled
control 'apache-forward-secrecy' do
  impact 1.0
  title 'Ensure Only Cipher Suites That Provide Forward Secrecy Are Enabled'
  desc 'Only cipher suites with forward secrecy should be enabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/ssl.conf')) do
    its('content') { should match(/ECDHE|DHE/) }
  end
end

# 57. Ensure All Web Content is Accessed via HTTPS
control 'apache-https-only' do
  impact 1.0
  title 'Ensure All Web Content is Accessed via HTTPS'
  desc 'All web content should be accessed via HTTPS.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/RewriteCond %{HTTPS} off/) }
    its('content') { should match(/RewriteRule \(.*\) https:\/\/%{HTTP_HOST}%{REQUEST_URI}/) }
  end
end

# 58. Set ServerToken to 'Prod'
control 'apache-servertokens-prod' do
  impact 1.0
  title 'Set ServerToken to Prod'
  desc 'ServerTokens should be set to Prod.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/security.conf')) do
    its('content') { should match(/^ServerTokens Prod/) }
  end
end

# 59. Set ServerSignature to 'Off'
control 'apache-serversignature-off' do
  impact 1.0
  title 'Set ServerSignature to Off'
  desc 'ServerSignature should be set to Off.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/security.conf')) do
    its('content') { should match(/^ServerSignature\s+Off$/) }
  end
end

# 60. Information Leakage via Default Apache Content
control 'apache-info-leak-default-content' do
  impact 1.0
  title 'Information Leakage via Default Apache Content'
  desc 'Default Apache content should not be present.'
  describe file('/var/www/html/index.html') do
    it { should_not exist }
  end
end

# 61. Information Leakage via ETag
control 'apache-info-leak-etag' do
  impact 1.0
  title 'Information Leakage via ETag'
  desc 'ETag header should be disabled.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/security.conf')) do
    its('content') { should match(/FileETag None/) }
  end
end

# 62. Set TimeOut to 10 or less
control 'apache-timeout' do
  impact 1.0
  title 'Set TimeOut to 10 or less'
  desc 'TimeOut should be set to 10 or less.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^TimeOut 10$/) }
  end
end

# 63. Set the KeepAlive directive to On
control 'apache-keepalive-on' do
  impact 1.0
  title 'Set the KeepAlive directive to On'
  desc 'KeepAlive should be set to On.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^KeepAlive On$/) }
  end
end

# 64. Set MaxKeepAliveRequests to 100 or greater
control 'apache-max-keepalive-requests' do
  impact 1.0
  title 'Set MaxKeepAliveRequests to 100 or greater'
  desc 'MaxKeepAliveRequests should be set to 100 or greater.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^MaxKeepAliveRequests (100|[1-9][0-9]{2,})$/) }
  end
end

# 65. Set KeepAliveTimeout Low to Mitigate Denial of Service
control 'apache-keepalive-timeout' do
  impact 1.0
  title 'Set KeepAliveTimeout Low to Mitigate Denial of Service'
  desc 'KeepAliveTimeout should be set low.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^KeepAliveTimeout [1-9]$/) }
  end
end

# 66. Set Timeout Limits for Request Headers
control 'apache-timeout-headers' do
  impact 1.0
  title 'Set Timeout Limits for Request Headers'
  desc 'Limit request headers timeout.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^HeaderTimeout [1-9]$/) }
  end
end

# 67. Set Timeout Limits for the Request Body
control 'apache-timeout-body' do
  impact 1.0
  title 'Set Timeout Limits for the Request Body'
  desc 'Limit request body timeout.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^BodyTimeout [1-9]$/) }
  end
end

# 68. Set the LimitRequestLine directive to 512 or less
control 'apache-limit-request-line' do
  impact 1.0
  title 'Set the LimitRequestLine directive to 512 or less'
  desc 'LimitRequestLine should be 512 or less.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^LimitRequestLine (\d|[1-4]\d\d|5[0-1][0-2])$/) }
  end
end

# 69. Set the LimitRequestFields directive to 100 or less
control 'apache-limit-request-fields' do
  impact 1.0
  title 'Set the LimitRequestFields directive to 100 or less'
  desc 'LimitRequestFields should be 100 or less.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^LimitRequestFields (\d|[1-9]\d|100)$/) }
  end
end

# 70. Set the LimitRequestFieldsize directive to 1024 or less
control 'apache-limit-request-fieldsize' do
  impact 1.0
  title 'Set the LimitRequestFieldsize directive to 1024 or less'
  desc 'LimitRequestFieldsize should be 1024 or less.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^LimitRequestFieldsize (\d|[1-9]\d{1,2}|10[0-1][0-9]|102[0-4])$/) }
  end
end

# 71. Set the LimitRequestBody directive to 102400 or less
control 'apache-limit-request-body' do
  impact 1.0
  title 'Set the LimitRequestBody directive to 102400 or less'
  desc 'LimitRequestBody should be 102400 or less.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    its('content') { should match(/^LimitRequestBody (\d|[1-9]\d{1,4}|[1-9]\d{2,3}|102[0-3][0-9]|10240[0-0])$/) }
  end
end

# 72. Run Apache Processes in the httpd_t Confined Context (config-only check)
control 'apache-selinux-httpd_t' do
  impact 1.0
  title 'Run Apache Processes in the httpd_t Confined Context (config-only)'
  desc 'Apache should be configured to run in the httpd_t SELinux context (config-only check).'
  # Check for a reference to httpd_t in a local SELinux policy/config file or documentation
  selinux_policy_file = File.join(apache_conf_dir, 'selinux-apache-policy.conf')
  describe file(selinux_policy_file) do
    it { should exist }
    its('content') { should match(/httpd_t/) }
  end
end

# 73. Ensure the httpd_t Type is Not in Permissive Mode
control 'apache-selinux-not-permissive' do
  impact 1.0
  title 'Ensure the httpd_t Type is Not in Permissive Mode'
  desc 'SELinux httpd_t type should not be in permissive mode.'
  describe command('getenforce') do
    its('stdout') { should_not match(/Permissive|Disabled/) }
  end
end

# 74. Ensure Only the Necessary SELinux Booleans are Enabled
control 'apache-selinux-booleans' do
  impact 1.0
  title 'Ensure Only the Necessary SELinux Booleans are Enabled'
  desc 'Only necessary SELinux booleans should be enabled.'
  describe command('getsebool -a | grep httpd') do
    its('stdout') { should_not match(/on/) } # Adjust as needed for your policy
  end
end

# 75. Enable the AppArmor Framework (config-only check)
control 'apache-apparmor-enabled' do
  impact 1.0
  title 'Enable the AppArmor Framework'
  desc 'AppArmor should be enabled (config-only check).'
  describe file(File.join("/Users/KMBL400649/Documents/Config_Check_Project/apache-profile/config", "apparmor.d/usr.sbin.apache2")) do
    it { should exist }
    its('content') { should match(/profile\susr\.sbin\.apache2/) }
  end
end

# 76. Customize the Apache AppArmor Profile
control 'apache-apparmor-profile' do
  impact 1.0
  title 'Customize the Apache AppArmor Profile'
  desc 'Apache AppArmor profile should be customized.'
  describe file(File.join(apache_conf_dir, 'apparmor.d/usr.sbin.apache2')) do
    it { should exist }
    its('content') { should match(/profile/) }
  end
end

# 77. Ensure Apache AppArmor Profile is in Enforce Mode
control 'apache-apparmor-enforce' do
  impact 1.0
  title 'Ensure Apache AppArmor Profile is in Enforce Mode'
  desc 'Apache AppArmor profile should be in enforce mode.'
  describe file(File.join(apache_conf_dir, 'apparmor.d/usr.sbin.apache2')) do
    its('content') { should match(/enforce/) }
  end
end

# 78. Ensure Access to .git Files Is Restricted
control 'apache-restrict-git-files' do
  impact 1.0
  title 'Ensure Access to .git Files Is Restricted'
  desc 'Access to .git files should be restricted.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    it { should exist }
    its('content') { should_not be_empty }
    # Multiline regex: match <FilesMatch ...> block containing Require all denied or Deny from all
    its('content') { should match(/<FilesMatch\s+["']?\\?\.git["']?\s*>\s*\n\s*(Require all denied|Deny from all)\s*\n\s*<\/FilesMatch>/im) }
  end
end

# 79. Ensure Access to .svn Files Is Restricted
control 'apache-restrict-svn-files' do
  impact 1.0
  title 'Ensure Access to .svn Files Is Restricted'
  desc 'Access to .svn files should be restricted.'
  describe file(File.join(apache_conf_dir, '/conf-enabled/hardening.conf')) do
    it { should exist }
    its('content') { should_not be_empty }
    its('content') { should match(/<FilesMatch\s+["']?\\?\.svn["']?\s*>\s*\n\s*(Require all denied|Deny from all)\s*\n\s*<\/FilesMatch>/im) }
  end
end

# 80. Ensure HTTP Header Referrer-Policy is set appropriately
control 'apache-referrer-policy' do
  impact 1.0
  title 'Ensure HTTP Header Referrer-Policy is set appropriately'
  desc 'Ensure the Referrer-Policy header is set to restrict information leakage.'
  describe file(File.join(apache_conf_dir, 'security.conf')) do
    its('content') { should match /Header always set Referrer-Policy "no-referrer"/ }
  end
end

# 81. Ensure Applicable Patches Are Applied
control 'apache-patches-applied' do
  impact 1.0
  title 'Ensure Applicable Patches Are Applied'
  desc 'Ensure the Apache server is running the latest patched version.'
  describe command('httpd -v || apache2 -v') do
    its('stdout') { should match /Apache\/2\.4\.*/ }
  end
end

# 82. Ensure the Basic and Digest Authentication Modules are Disabled
control 'apache-disable-auth-modules' do
  impact 1.0
  title 'Ensure the Basic and Digest Authentication Modules are Disabled'
  desc 'Disable the Basic and Digest authentication modules to prevent unauthorized access.'
  describe file(File.join(apache_conf_dir, 'httpd.conf')) do
    its('content') { should_not match /LoadModule auth_basic_module/ }
    its('content') { should_not match /LoadModule auth_digest_module/ }
  end
end

