#!/bin/bash

# Wrapper script to run all InSpec profiles

# Define the directory containing the profiles
PROFILES_DIR="/app/controls"
REPORTS_DIR="/app/reports"

# Ensure the reports directory exists
mkdir -p "$REPORTS_DIR"

# Accept the InSpec license
export INSPEC_LICENSE="accept"

# Loop through each profile and execute it
for PROFILE in "$PROFILES_DIR"/*; do
  if [ -d "$PROFILE" ]; then
    PROFILE_NAME=$(basename "$PROFILE")
    echo "Running profile: $PROFILE_NAME"
    inspec exec "$PROFILE" --chef-license accept --reporter html:"$REPORTS_DIR/$PROFILE_NAME.html"
  fi
done

echo "All profiles executed. Reports are available in $REPORTS_DIR."