#!/bin/bash

# Wrapper script to check configuration files for detected web servers

# Default values
PROFILES_DIR="${PROFILES_DIR:-./src}"
REPORTS_DIR="${REPORTS_DIR:-./reports}"
OUTPUT_FORMAT="${OUTPUT_FORMAT:-html}"

# Ensure the reports directory exists
mkdir -p "$REPORTS_DIR"

# Accept the InSpec license
export INSPEC_LICENSE="accept"

# Log file for execution details
LOG_FILE="$REPORTS_DIR/execution.log"

# Detect web servers and check corresponding configuration files
WEB_SERVERS=("apache" "nginx" "iis" "jboss" "tomcat7" "tomcat8" "tomcat9" "ibm-httpd" "ibm-websphere" "tomcat on windows")

# Change the directory to test for configuration files
CONFIG_DIR="./test"

# Update the loop to ensure all web servers are checked even after failure
for SERVER in "${WEB_SERVERS[@]}"; do
  CONFIG_FILES="$CONFIG_DIR/$SERVER"
  if [ -d "$CONFIG_FILES" ]; then
    CONFIG_NAME=$(basename "$CONFIG_FILES")
    echo "Checking configuration files for detected web server: $CONFIG_NAME"
    echo "Checking configuration files for detected web server: $CONFIG_NAME" >> "$LOG_FILE"

    # Perform checks on configuration files
    for FILE in $(find "$CONFIG_FILES" -type f); do
      echo "Checking file: $FILE" >> "$LOG_FILE"
      # Placeholder for actual file validation logic
      if [ -r "$FILE" ]; then
        echo "File $FILE is readable and valid." >> "$LOG_FILE"
      else
        echo "File $FILE is not readable or valid." >> "$LOG_FILE"
      fi
    done

    # Run inspec exec with detailed error logging
    echo "Running security controls for detected web server: $CONFIG_NAME" >> "$LOG_FILE"
    inspec exec "src/$SERVER" --chef-license accept --reporter html:reports/$SERVER.html --log-level debug >> "$LOG_FILE" 2>&1 || {
      echo "❌ Failed to execute security controls for: $CONFIG_NAME" >> "$LOG_FILE"
      echo "Error details:" >> "$LOG_FILE"
      tail -n 20 "$LOG_FILE" >> "$LOG_FILE"
    }
  else
    echo "No configuration files found for web server: $SERVER"
    echo "No configuration files found for web server: $SERVER" >> "$LOG_FILE"
  fi

done || true

# Update the final message
echo "Configuration checks completed for all detected web servers. Logs are available in $REPORTS_DIR."

RUN apt-get update && apt-get install -y apache2-utils && apt-get clean && rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*