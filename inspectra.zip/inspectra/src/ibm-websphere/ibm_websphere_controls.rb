title 'IBM Websphere Server Config'

DOCUMENT_ROOT = '/app/test/ibm-websphere'
CONFIG_FILES = [
  '/app/test/ibm-websphere/security.xml',
  '/app/test/ibm-websphere/server.xml',
  '/app/test/ibm-websphere/resources.xml',
  '/app/test/ibm-websphere/variables.xml'
]
LOG_DIR = '/app/test/ibm-websphere/logs'
BASE_CONFIG_DIR = '/app/test/ibm-websphere/'

# 1. Passwords should be protected from Standard Input
control 'was-01' do
  impact 1.0
  title 'Passwords should be protected from Standard Input'
  desc 'Ensure passwords are not set via standard input in config files.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should_not match(/password\s*=\s*["']?stdin["']?/) }
    end
  end
end

# 2. Password caching should be disabled
control 'was-02' do
  impact 1.0
  title 'Password caching should be disabled'
  desc 'Ensure password caching is disabled in security config.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/passwordCachingEnabled\s*=\s*["']?false["']?/) }
    end
  end
end

# 3. Administration security should be enabled
control 'was-03' do
  impact 1.0
  title 'Administration security should be enabled'
  desc 'Ensure administrative security is enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/adminEnabled\s*=\s*["']?true["']?/) }
    end
  end
end

# 4. Current Patches should be applied to the system
control 'was-04' do
  impact 0.7
  title 'Current Patches should be applied to the system'
  desc 'Check config for patch/version info (manual review may be required).'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<version>|patch|fixpack/i) }
    end
  end
end

# 5. Service Integration Bus should be secured
control 'was-05' do
  impact 1.0
  title 'Service Integration Bus should be secured'
  desc 'Ensure SIBus security is enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<SIBus.*securityEnabled=["']?true["']?/) }
    end
  end
end

# 6. WAS to LDAP link should be encrypted
control 'was-06' do
  impact 1.0
  title 'WAS to LDAP link should be encrypted'
  desc 'Ensure LDAP connections use SSL/TLS.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<ldap.*sslEnabled=["']?true["']?/) }
    end
  end
end

# 7. Web Server to Web container link should be encrypted
control 'was-07' do
  impact 1.0
  title 'Web Server to Web container link should be encrypted'
  desc 'Ensure HTTPS is used for web server to container communication.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<transport.*protocol=["']?https["']?/) }
    end
  end
end

# 8. Distribution and Consistency Services Link should be encrypted
control 'was-08' do
  impact 1.0
  title 'Distribution and Consistency Services Link should be encrypted'
  desc 'Ensure DCS links are encrypted.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<dcs.*sslEnabled=["']?true["']?/) }
    end
  end
end

# 9. WebSphere MQ messaging links should be encrypted
control 'was-09' do
  impact 1.0
  title 'WebSphere MQ messaging links should be encrypted'
  desc 'Ensure MQ links use SSL/TLS.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<MQ.*sslEnabled=["']?true["']?/) }
    end
  end
end

# 10. Sample applications should be removed from production
control 'was-10' do
  impact 1.0
  title 'Sample applications should be removed from production'
  desc 'Ensure sample apps are not present in config.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should_not match(/<application.*sample/i) }
    end
  end
end

# 11. LTPA cookie format should be used
control 'was-11' do
  impact 1.0
  title 'LTPA cookie format should be used'
  desc 'Ensure LTPA is configured for SSO.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<LTPAKeySet|ltpa/i) }
    end
  end
end

# 12. Single sign on for HTTP requests should be secured
control 'was-12' do
  impact 1.0
  title 'Single sign on for HTTP requests should be secured'
  desc 'Ensure SSO is enabled and secure.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<singleSignon.*enabled=["']?true["']?/) }
    end
  end
end

# 13. Application security at the global security level should be enabled
control 'was-13' do
  impact 1.0
  title 'Application security at the global security level should be enabled'
  desc 'Ensure global application security is enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/appEnabled\s*=\s*["']?true["']?/) }
    end
  end
end

# 14. Session security integration should be enabled
control 'was-14' do
  impact 1.0
  title 'Session security integration should be enabled'
  desc 'Ensure session security integration is enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/sessionSecurityIntegration\s*=\s*["']?true["']?/) }
    end
  end
end

# 15. Configuration files should be protected
control 'was-15' do
  impact 1.0
  title 'Configuration files should be protected'
  desc 'Check config file permissions (manual review may be required).'
  CONFIG_FILES.each do |file|
    describe file(file) do
      it { should be_readable.by('owner') }
      it { should_not be_writable.by('others') }
    end
  end
end

# 16. Java Naming and Directory Interface should be protected
control 'was-16' do
  impact 1.0
  title 'Java Naming and Directory Interface should be protected'
  desc 'Ensure JNDI security is enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<jndi.*securityEnabled=["']?true["']?/) }
    end
  end
end

# 17. File systems should be protected using JAVA 2 security
control 'was-17' do
  impact 1.0
  title 'File systems should be protected using JAVA 2 security'
  desc 'Ensure Java 2 security is enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/java2SecurityEnabled\s*=\s*["']?true["']?/) }
    end
  end
end

# 18. Authorization should be controlled through administrative roles
control 'was-18' do
  impact 1.0
  title 'Authorization should be controlled through administrative roles'
  desc 'Ensure admin roles are defined in config.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<role.*name=["']?admin["']?/) }
    end
  end
end

# 19. Security auditing feature should be enabled
control 'was-19' do
  impact 1.0
  title 'Security auditing feature should be enabled'
  desc 'Ensure security auditing is enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<audit.*enabled=["']?true["']?/) }
    end
  end
end

# 20. Creating an authentication alias
control 'was-20' do
  impact 1.0
  title 'Creating an authentication alias'
  desc 'Ensure authentication aliases are defined in config.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<authData.*alias=/) }
    end
  end
end
