title 'JBOSS EAP Server Config'

DOCUMENT_ROOT = '/app/test/jboss'
CONFIG_FILES = [
  '/app/test/jboss/standalone.xml',
  '/app/test/jboss/host.xml'
]
BASE_CONFIG_DIR = '/app/test/jboss/'

# 1. Check for secure interface and socket binding configuration
control 'jboss-eap-01' do
  impact 1.0
  title 'Interfaces and Socket Bindings'
  desc 'Check for secure interface and socket binding configuration.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<interface.*security-realm=/) }
      its('content') { should match(/<socket-binding-group/) }
    end
  end
end

# 2. Ensure legacy security subsystem is enabled
control 'jboss-eap-02' do
  impact 1.0
  title 'Legacy Security Subsystem'
  desc 'Ensure legacy security subsystem is enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<subsystem xmlns="urn:jboss:domain:security/) }
    end
  end
end

# 3. Security subsystem should be present
control 'jboss-eap-03' do
  impact 1.0
  title 'Enabling the security subsystem'
  desc 'Security subsystem should be present.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<subsystem xmlns="urn:jboss:domain:security/) }
    end
  end
end

# 4. Management interfaces should use authentication and secure socket bindings
control 'jboss-eap-04' do
  impact 1.0
  title 'Authentication and socket bindings for management interfaces'
  desc 'Management interfaces should use authentication and secure socket bindings.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<management-interfaces>/) }
      its('content') { should match(/<http-interface.*security-realm=/) }
    end
  end
end

# 5. HTTPS listener should be configured
control 'jboss-eap-05' do
  impact 1.0
  title 'HTTPS Listener Reference'
  desc 'HTTPS listener should be configured.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<https-listener/) }
    end
  end
end

# 6. Management console should be disabled if not needed
control 'jboss-eap-06' do
  impact 1.0
  title 'Disabling the Management Console'
  desc 'Management console should be disabled if not needed.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should_not match(/<console-handler/) }
    end
  end
end

# 7. Remote JMX access should be disabled
control 'jboss-eap-07' do
  impact 1.0
  title 'Disabling Remote Access to JMX'
  desc 'Remote JMX access should be disabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should_not match(/<connector name="jmxrmi"/) }
    end
  end
end

# 8. Silent authentication should be disabled
control 'jboss-eap-08' do
  impact 1.0
  title 'Silent Authentication'
  desc 'Silent authentication should be disabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should_not match(/silent-authentication-enabled="true"/) }
    end
  end
end

# 9. Management interfaces should be configured for one-way SSL/TLS
control 'jboss-eap-09' do
  impact 1.0
  title 'One-way SSL/TLS for Management Interfaces'
  desc 'Management interfaces should be configured for one-way SSL/TLS.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<ssl.*key-store/) }
    end
  end
end

# 10. File audit logging should be enabled
control 'jboss-eap-10' do
  impact 1.0
  title 'File Audit Logging'
  desc 'File audit logging should be enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<file-handler/) }
    end
  end
end

# 11. Periodic rotating file audit logging should be enabled
control 'jboss-eap-11' do
  impact 1.0
  title 'Periodic Rotating File Audit Logging'
  desc 'Periodic rotating file audit logging should be enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<periodic-rotating-file-handler/) }
    end
  end
end

# 12. Size rotating file audit logging should be enabled
control 'jboss-eap-12' do
  impact 1.0
  title 'Size Rotating File Audit Logging'
  desc 'Size rotating file audit logging should be enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<size-rotating-file-handler/) }
    end
  end
end

# 13. Syslog audit logging should be enabled
control 'jboss-eap-13' do
  impact 1.0
  title 'Syslog Audit Logging'
  desc 'Syslog audit logging should be enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<syslog-handler/) }
    end
  end
end

# 14. SSL or TLS should be configured for legacy core management authentication
control 'jboss-eap-14' do
  impact 1.0
  title 'SSL/TLS for Legacy Core Management Auth'
  desc 'SSL or TLS should be configured for legacy core management authentication.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<ssl.*key-store/) }
    end
  end
end

# 15. Role-based access control should be enabled
control 'jboss-eap-15' do
  impact 1.0
  title 'Role-Based Access Control'
  desc 'Role-based access control should be enabled.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<role-mapping/) }
    end
  end
end

# 16. Permission combination policy should be set
control 'jboss-eap-16' do
  impact 1.0
  title 'Permission Combination Policy'
  desc 'Permission combination policy should be set.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<permission-combination-policy/) }
    end
  end
end

# 17. Credential store should be configured for standalone server
control 'jboss-eap-17' do
  impact 1.0
  title 'Credential Store for Standalone Server'
  desc 'Credential store should be configured for standalone server.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<credential-store/) }
    end
  end
end

# 18. Credential should be added to the credential store
control 'jboss-eap-18' do
  impact 1.0
  title 'Add Credential to Credential Store'
  desc 'Credential should be added to the credential store.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/<credential name=/) }
    end
  end
end

# 19. Stored credential should be referenced in configuration
control 'jboss-eap-19' do
  impact 1.0
  title 'Use Stored Credential in Configuration'
  desc 'Stored credential should be referenced in configuration.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/\$\{VAULT::/) }
    end
  end
end

# 20. Encrypted sensitive string should be used in application config
control 'jboss-eap-20' do
  impact 1.0
  title 'Encrypted Sensitive String in Application'
  desc 'Encrypted sensitive string should be used in application config.'
  CONFIG_FILES.each do |file|
    describe file(file) do
      its('content') { should match(/ENC\(/) }
    end
  end
end
