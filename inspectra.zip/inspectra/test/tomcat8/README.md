# Tomcat 7 Configuration
This folder contains configuration files for Tomcat 7, adapted from Tomcat 8 settings.
