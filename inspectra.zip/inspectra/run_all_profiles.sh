#!/bin/bash

# Wrapper script to run security controls against detected web servers

# Default values
PROFILES_DIR="${PROFILES_DIR:-./src}"
REPORTS_DIR="${REPORTS_DIR:-./reports}"
OUTPUT_FORMAT="${OUTPUT_FORMAT:-html}"

# Ensure the reports directory exists
mkdir -p "$REPORTS_DIR"

# Accept the InSpec license
export INSPEC_LICENSE="accept"

# Log file for execution details
LOG_FILE="$REPORTS_DIR/execution.log"

# Detect web servers and run corresponding profiles
WEB_SERVERS=("apache" "nginx" "iis" "jboss" "tomcat7" "tomcat8" "tomcat9" "ibm-httpd" "ibm-websphere" "tomcat on windows")

for SERVER in "${WEB_SERVERS[@]}"; do
  PROFILE="$PROFILES_DIR/$SERVER"
  if [ -d "$PROFILE" ]; then
    PROFILE_NAME=$(basename "$PROFILE")
    echo "Running security controls for detected web server: $PROFILE_NAME"
    echo "Running security controls for detected web server: $PROFILE_NAME" >> "$LOG_FILE"

    # Execute the profile with the specified output format
    inspec exec "$PROFILE" --chef-license accept --reporter "$OUTPUT_FORMAT:$REPORTS_DIR/$PROFILE_NAME.$OUTPUT_FORMAT" >> "$LOG_FILE" 2>&1 || {
      echo "❌ Failed to execute security controls for: $PROFILE_NAME"
      exit 1
    }
  else
    echo "No profile found for web server: $SERVER"
    echo "No profile found for web server: $SERVER" >> "$LOG_FILE"
  fi

done

echo "Security controls executed for all detected web servers. Reports are available in $REPORTS_DIR."